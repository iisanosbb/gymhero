<template>
  <QuestionTemplate :questionNumber="4" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question4',
  components: {
    QuestionTemplate
  }
}
</script>
