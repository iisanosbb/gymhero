<template>
  <QuestionTemplate :questionNumber="9" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question9',
  components: {
    QuestionTemplate
  }
}
</script>
