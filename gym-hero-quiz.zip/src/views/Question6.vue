<template>
  <QuestionTemplate :questionNumber="6" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question6',
  components: {
    QuestionTemplate
  }
}
</script>
