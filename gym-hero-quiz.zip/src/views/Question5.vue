<template>
  <QuestionTemplate :questionNumber="5" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question5',
  components: {
    QuestionTemplate
  }
}
</script>
