<template>
  <QuestionTemplate :questionNumber="8" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question8',
  components: {
    QuestionTemplate
  }
}
</script>
