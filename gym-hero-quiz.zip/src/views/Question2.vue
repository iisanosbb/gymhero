<template>
  <QuestionTemplate :questionNumber="2" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question2',
  components: {
    QuestionTemplate
  }
}
</script>
