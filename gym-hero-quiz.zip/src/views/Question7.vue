<template>
  <QuestionTemplate :questionNumber="7" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question7',
  components: {
    QuestionTemplate
  }
}
</script>
