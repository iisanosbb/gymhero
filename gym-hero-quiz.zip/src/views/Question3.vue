<template>
  <QuestionTemplate :questionNumber="3" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question3',
  components: {
    QuestionTemplate
  }
}
</script>
