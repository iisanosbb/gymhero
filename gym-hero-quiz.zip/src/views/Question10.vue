<template>
  <QuestionTemplate :questionNumber="10" />
</template>

<script>
import QuestionTemplate from '../components/QuestionTemplate.vue'

export default {
  name: 'Question10',
  components: {
    QuestionTemplate
  }
}
</script>
